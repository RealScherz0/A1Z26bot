const { Client, GatewayIntentBits } = require(`discord.js`);

const prefix = "!";

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.DirectMessages, GatewayIntentBits.MessageContent] });

client.on("ready", () => {
  console.log("Bot is online!");
  client.user.setActivity("Use ! to encrypt your message", {type: "WATCHING" });
});

client.on("messageCreate", (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  //COMMANDS
  if (command === 'e') {
    const text = args.join(' ');
    let result = '';
    for (let i = 0; i < text.length; i++) {
        let charCode = text.charCodeAt(i);
        if (charCode >= 65 && charCode <= 90) {
            result += (charCode - 64) + '-';
        } else if (charCode >= 97 && charCode <= 122) {
            result += (charCode - 96) + '-';
        } else {
            result += text[i];
        }
    }
    message.author.send(result.slice(0, -1));
  } else if (command === "test") {
    message.author.send("Bot is working!");
  } else if (command === 'd') {
    const text = a1z26ToText(args[0]);
    message.author.send(`Translated message: ${text}`);
  }
});

function a1z26ToText(str) {
  const numArr = str.split(/-|\s+/);
  let result = "";
  
  for (let i = 0; i < numArr.length; i++) {
    const num = parseInt(numArr[i], 10);
    
    if (!isNaN(num)) {
      result += String.fromCharCode(num + 96);
    } else {
      result += numArr[i];
    }
  }
  
  return result;
}

client.login("MTA3ODE4NTc4MDg0Mjg2ODc0Ng.GOzZVT.90U0LCy9axnz4WQnioVPl-yqnAJK7fl56l2lEM");
